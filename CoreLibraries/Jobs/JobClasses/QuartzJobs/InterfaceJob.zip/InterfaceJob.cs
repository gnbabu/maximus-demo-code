﻿using Quartz;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;

using System.Data;
using System.Data.SqlClient;

namespace MAXIMUS.Core.Libraries.QuartzJobs
{
    /// <summary>
    ///     Author(s):      Ahackl
    ///     Date:           2017.06.12
    ///     Name:           QuartzJob
    ///     Description:    Interface Job
    /// </summary>
    [DisallowConcurrentExecution]
    public class InterfaceJob : QuartzJob
    {
        /// <summary>
        ///     Author(s):      Ahackl
        ///     Date:           2017.06.12
        ///     Name:           QuartzJob
        ///     Description:    Job Type Id
        /// </summary>
        public override int JobTypesID
        {
            get { return 1; }
        }


        /// <summary>
        ///     Author(s):      Ahackl
        ///     Date:           2017.06.12
        ///     Name:           QuartzJob
        ///     Description:    Main Execution Method
        /// </summary>
        public override void Execute(Quartz.IJobExecutionContext context)
        {
            int logCnt = 0;

            string assemblyName = Methods.GetStringValue(context.JobDetail.JobDataMap.Get("AssemblyName"));
            string className = Methods.GetStringValue(context.JobDetail.JobDataMap.Get("ClassName"));
            string assemblyPath = Methods.GetStringValue(context.JobDetail.JobDataMap.Get("AssemblyPath"));
            bool sendEmail = Methods.GetBoolean(context.JobDetail.JobDataMap.Get("EmailEndOfExecution"));
            Logging log = new Logging();
            if (assemblyPath.Length > 0)
            {
                assemblyPath = new DirectoryInfo(assemblyPath).FullName;
            }
            else
            {
                assemblyPath = new FileInfo(Assembly.GetExecutingAssembly().Location).DirectoryName;
            }
            if (System.Diagnostics.Debugger.IsAttached)
            {
                assemblyPath = @"C:\Projects\DC_PDMS\trunk\PDMS\PDMSDataExchange\bin\Debug\";
            }
            string assemblyFullName = Path.Combine(new Uri(assemblyPath).LocalPath, assemblyName);

            Assembly jobAssembly = Assembly.LoadFrom(assemblyFullName);
            Type classType = jobAssembly.GetType(className);

            if (classType == null)
            {
                throw new ArgumentException(string.Format("Class '{0}' does not exist in Assembly '{1}'", className, assemblyFullName));
            }

            //Since this is a quartz job that is multithreaded it's thread is a new guid
            var jobClass = (IJob)Activator.CreateInstance(classType, Guid.NewGuid());

            Guid jobId = Guid.Parse((string)context.JobDetail.JobDataMap.Get("JobID"));

            log.CreateLogEntry(String.Format("Executing JobId {0}", jobId), +logCnt);

            ((IJob)jobClass).ExecuteJob(jobId);

            log.CreateLogEntry(String.Format("JobId {0} completed", jobId), +logCnt);

            // if the job should send notifications
            if (sendEmail)
            {
                // retrieve job log from database
                DataSet logEntries = GetJobLog(this.ThreadId.ToString());

                // convert dataset to html table
                string logEntriesTable = GetDataTableAsHTML(logEntries.Tables[0]);

                // jf :: 2020.10.08 :: Fix issue with not getting job logs
                // SendEmail(Constants.emptyGuid, logEntriesTable);
                SendEmail(JobId, logEntriesTable);
            }
        }
        private DataSet GetJobLog(string threadId)
        {
            DataSet returnValue = new DataSet();

            try
            {
                // execute the select stored procedure with parameters
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(SqlParms.CreateParameter("ThreadId", DbType.Guid, threadId, false));
                returnValue = DataAccess.ExecuteStoredProcedure("usp_GetJobLogByThreadId", parameters, "Jobs");
                return returnValue;
            }
            catch (Exception ex)
            {
                throw CoreException.ThrowException(this.ThreadId, ex);
            }
        }

    }

}
